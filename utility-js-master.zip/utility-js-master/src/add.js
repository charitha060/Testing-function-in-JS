const add = (first,second) => {
    return first + second;   
}
module.exports = add;
